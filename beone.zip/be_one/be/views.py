from django.shortcuts import render
from .models import *
from django.urls import reverse
from ckeditor.fields import RichTextField
from django.db.models import Q

# Create your views here.
def index(request):
	posts = Post.objects.all()

	if request.method == 'POST':
		name = request.POST['name']
		surname = request.POST['surname']
		message = request.POST['message']
		Contact.objects.create(name=name,surname=surname,message=message)
		print('#'*50)
	else:
		print('error'*10)
	context = {
	'post':posts,
	}
	return render(request, 'index.html',context)

def teacher(request):
	teacher = Teacher.objects.all()

	context = {
	'teacher':teacher,
	}
	return render(request, 'teacher.html', context)