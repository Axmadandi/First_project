from django.apps import AppConfig


class BeConfig(AppConfig):
    name = 'be'
