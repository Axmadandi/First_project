from django.db import models
from django.urls import reverse

# Create your models here.


class Post(models.Model):
	title = models.CharField('title', max_length=50)
	body = models.CharField('body', max_length=500)
	img = models.ImageField('img', upload_to='img/')

	class Meta:
		verbose_name = 'Post'
		verbose_name_plural = 'Postlar'


	def __str__(self):
		return f"{self.title}"


class Teacher(models.Model):
	name = models.CharField('name',max_length=50)
	surname = models.CharField('surname',max_length=50)
	body = models.CharField('body', max_length=500)
	ish_tajribasi = models.CharField('Ish tajribasi', max_length=20)
	image = models.ImageField('Rasmi', upload_to='img/')

	class Meta:
		verbose_name = 'Teacher'
		verbose_name_plural = 'Teacherlar'


	def __str__(self):
		return f"{self.name}"


class Contact(models.Model):
	name = models.CharField('name',max_length=50)
	surname = models.CharField('surname',max_length=50)
	message = models.TextField('message')

	class Meta:
		verbose_name = 'Aloqa'
		verbose_name_plural = 'Aloqalar'

	def __str__(self):
		return f"{self.name}"


